var searchData=
[
  ['nueva_5frejilla',['nueva_rejilla',['../class_cjt__rejillas.html#a4dd8bc72a290429dd3988d8f2e1603b7',1,'Cjt_rejillas']]],
  ['nuevo_5fmensaje',['nuevo_mensaje',['../class_cjt__mensajes.html#ac0d556f32f827b21e873f64022bc83fe',1,'Cjt_mensajes']]],
  ['nuevo_5fpatron',['nuevo_patron',['../class_cjt__patrones.html#ab9efedd70f12de2e2e4f5302874221d9',1,'Cjt_patrones']]]
];
