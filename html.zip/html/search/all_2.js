var searchData=
[
  ['decodificar',['decodificar',['../class_rejilla.html#ac7bd2695bd5b6610e3cd20bc2f53cf67',1,'Rejilla']]],
  ['decodificar_5frejilla',['decodificar_rejilla',['../class_cjt__rejillas.html#a47fba1218f1b5bc6a9c0425e12620f89',1,'Cjt_rejillas']]]
];
