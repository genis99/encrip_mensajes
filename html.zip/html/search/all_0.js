var searchData=
[
  ['borrar_5fmensaje',['borrar_mensaje',['../class_cjt__mensajes.html#a41a8f95df6807de9ddd4f26b24a83db1',1,'Cjt_mensajes']]]
];
