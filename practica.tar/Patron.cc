#include "Patron.hh"

Patron::Patron() {
    
}

BinTree<int> Patron::consultar_patron() const {
    BinTree<int> b;
    return b;
}

void Patron::leer() {
    
}

void Patron::escribir() {
    
}
